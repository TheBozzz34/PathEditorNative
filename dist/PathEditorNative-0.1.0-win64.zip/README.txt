Path Editor Native

This package contains a portable build of the Windows PATH editor.

Usage:
1. Run PathEditorNative.exe
2. Use "Restart as Admin" in-app when you need to save System PATH
3. Restart any open terminal/app to pick up PATH changes

Notes:
- User PATH changes do not require administrator privileges.
- System PATH changes require an elevated process.
